import re


def create_tasks(goal):
    goal = goal.strip()

    if not goal:
        return []

    text = goal.lower()

    # Detect the type of goal
    if any(word in text for word in ["birthday", "party", "celebration", "event"]):
        tasks = [
            "Define the event requirements, date, location, and number of people.",
            "Prepare the guest list and send invitations.",
            "Plan the food, drinks, and catering requirements.",
            "Arrange decorations and required materials.",
            "Plan activities or entertainment for the event.",
            "Confirm all arrangements and prepare a final checklist."
        ]

    elif any(word in text for word in ["trip", "travel", "vacation", "tour", "goa"]):
        tasks = [
            "Define the destination, dates, budget, and number of travelers.",
            "Plan the travel route and transportation.",
            "Research and select suitable accommodation.",
            "Create a day-by-day itinerary.",
            "Prepare required documents, bookings, and travel essentials.",
            "Review the complete trip plan and confirm all reservations."
        ]

    elif any(word in text for word in ["fitness", "workout", "exercise", "gym"]):
        tasks = [
            "Define the fitness goal and current activity level.",
            "Create a suitable weekly workout schedule.",
            "Plan warm-up, exercise, and recovery activities.",
            "Set realistic nutrition and hydration goals.",
            "Track workouts and progress regularly.",
            "Review progress and adjust the plan when necessary."
        ]

    elif any(word in text for word in ["project", "software", "app", "website", "build"]):
        tasks = [
            "Define the project objective and required features.",
            "Identify the technologies, tools, and resources required.",
            "Break the project into smaller development tasks.",
            "Implement the main features step by step.",
            "Test the project and fix errors.",
            "Review the final project and prepare it for demonstration."
        ]

    elif any(word in text for word in ["presentation", "ppt", "seminar"]):
        tasks = [
            "Define the presentation topic and objective.",
            "Research the important information and key points.",
            "Organize the content into a logical structure.",
            "Create the presentation slides.",
            "Practice explaining the presentation clearly.",
            "Review the slides and make final improvements."
        ]

    elif any(word in text for word in ["business", "startup", "company"]):
        tasks = [
            "Define the business idea, target customers, and objective.",
            "Research the target market and competitors.",
            "Define the product or service and pricing approach.",
            "Prepare a basic marketing and customer acquisition plan.",
            "Estimate the required budget and resources.",
            "Create an execution plan and define the first milestones."
        ]

    else:
        # Generic goal — works for unknown examples too
        tasks = [
            f"Clearly define the requirements and expected outcome for: {goal}.",
            "Identify the resources, information, and tools required.",
            "Break the goal into smaller practical steps.",
            "Complete the most important step first.",
            "Review the progress and solve any problems that arise.",
            "Complete the remaining steps and verify the final result.",
            "Review the completed work against the original goal."
        ]

    # Give every task a priority
    result = []

    for i, task in enumerate(tasks):
        if i < 2:
            priority = "High"
        elif i < 5:
            priority = "Medium"
        else:
            priority = "Low"

        result.append({
            "task": task,
    "priority": priority,
    "estimated_time": "30 minutes" if i < 2 else "1 hour"
        })

    return result