import streamlit as st

from agent import create_tasks
from planner import prioritize_tasks
from executor import execute_task


st.set_page_config(
    page_title="AI Autonomous Task Assistant",
    page_icon="🤖",
    layout="wide"
)

st.title("🤖 AutoTask AI")
st.subheader("Your Autonomous Goal-to-Action Assistant")

st.write(
    "Enter your goal and the assistant will "
    "break it into tasks, prioritize them, and execute them."
)


# Store tasks so they don't disappear
if "tasks" not in st.session_state:
    st.session_state.tasks = []
if "completed" not in st.session_state:
    st.session_state.completed = 0

# Goal input
goal = st.text_area(
    "🎯 Enter your goal",
    placeholder="Example: Prepare for my Python exam in 7 days"
)


# Create plan
if st.button("🚀 Create My Plan"):

    if goal.strip() == "":
        st.warning("Please enter a goal.")

    else:

        tasks = create_tasks(goal)

        tasks = prioritize_tasks(tasks)

        st.session_state.tasks = tasks


# Display tasks
if st.session_state.tasks:

    st.subheader("📊 Task Dashboard")

    total_tasks = len(st.session_state.tasks)

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("📋 Total Tasks", total_tasks)

    with col2:
        st.metric("✅ Completed",
     st.session_state.get("completed", 0))


    with col3:
        st.metric(
    "⏳ Pending",
    total_tasks - st.session_state.get("completed", 0)
)
    completed_tasks = st.session_state.get("completed", 0)

    if total_tasks > 0:
        progress = completed_tasks / total_tasks
    else:
        progress = 0

    st.write("📈 Overall Progress")

    st.progress(progress)

    st.write(
        f"{completed_tasks} of {total_tasks} tasks completed"
    )

    st.success("✅ Your plan is ready!")

    st.subheader("📋 Task Plan")

    for number, task in enumerate(
        st.session_state.tasks,
        start=1
    ):

        st.write(
            f"### {number}. {task['task']}"
        )

        st.write(
            f"⭐ Priority: *{task['priority']}*"
        )

        st.write(
            f"⏱️ Estimated time: {task.get('estimated_time', 'Not specified')}"
        )

        st.divider()


    # Autonomous execution
    st.subheader("⚡ Autonomous Execution")

    if st.button("▶️ Execute Tasks"):

        completed = 0
        st.session_state.completed = 0

        for task in st.session_state.tasks:

            result = execute_task(task)

            st.success(
                "✅ Completed: " + result["task"]
            )

            completed += 1
            st.session_state.completed = completed


        progress = completed / len(
            st.session_state.tasks
        )

        st.progress(progress)

        st.success(
            f"🎉 Completed {completed}/"
            f"{len(st.session_state.tasks)} tasks!"
        )