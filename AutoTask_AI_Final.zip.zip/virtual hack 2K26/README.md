# 🤖 AutoTask AI

## AI-Powered Autonomous Task Assistant

AutoTask AI is an autonomous task assistant that converts a user's high-level goal into smaller actionable tasks, prioritizes them, executes them, and tracks progress through a dashboard.

## 🎯 Problem

Users often have large goals but don't know how to divide them into manageable tasks or decide which task should be completed first.

## 💡 Solution

AutoTask AI provides a simple goal-to-action workflow:

User Goal
↓
Task Breakdown
↓
Priority Assignment
↓
Autonomous Execution
↓
Progress Dashboard

## ✨ Features

- 🎯 Goal-based task planning
- 📋 Automatic task breakdown
- ⭐ Task prioritization
- ⚡ Autonomous task execution
- 📊 Task dashboard
- 📈 Progress tracking
- ✅ Completed and pending task tracking

## 🛠️ Technologies Used

- Python
- Streamlit
- OpenAI libraries
- Python-dotenv

## 🚀 Example

User enters:

"Prepare for my Python exam in 7 days"

The system generates tasks such as:

1. Understand important topics
2. Create short notes
3. Practice important questions
4. Review difficult topics
5. Take a mock test

The assistant then executes the tasks and updates the dashboard.

## 🏗️ Project Structure

- app.py - Main application interface
- agent.py - Goal-to-task generation
- planner.py - Task prioritization
- executor.py - Task execution
- .env - Environment configuration
- requirements.txt - Required Python packages

## 🎯 Future Improvements

- Dynamic AI-powered replanning
- Task dependencies
- Deadline-based prioritization
- Notifications and reminders
- Calendar integration
- More advanced autonomous actions

## 🏆 Hackathon Objective

The project demonstrates how AI agents can transform high-level goals into actionable plans and autonomously manage task execution with minimal human intervention.