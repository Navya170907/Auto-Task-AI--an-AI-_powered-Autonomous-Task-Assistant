def execute_task(task):

    return {
        "task": task["task"],
        "status": "Completed"
    }