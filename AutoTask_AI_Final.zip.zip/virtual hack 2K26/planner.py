def prioritize_tasks(tasks):

    priority_order = {
        "High": 1,
        "Medium": 2,
        "Low": 3
    }

    tasks.sort(
        key=lambda task: priority_order.get(
            task["priority"], 4
        )
    )

    return tasks